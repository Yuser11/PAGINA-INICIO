function myFunction() {
    document.getElementById("menu").classList.toggle("show");
  }